import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cms-contact-detail',
  templateUrl: './contact-detail.component.html',
  styleUrls: ['./contact-detail.component.css']
})
export class ContactDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
